"""Relational persistence adapter."""

