"""Framework-independent domain models."""

