"""Model provider adapters."""

